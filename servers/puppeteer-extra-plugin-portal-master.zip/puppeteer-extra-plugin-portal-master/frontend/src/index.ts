import './index.css';
import App from './app';

// eslint-disable-next-line no-new
new App();
