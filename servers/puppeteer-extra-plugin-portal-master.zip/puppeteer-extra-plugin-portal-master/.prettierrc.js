module.exports = {
  printWidth: 100,
  singleQuote: true,
};
