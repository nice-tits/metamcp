#!/bin/bash
npm install
node agent_browser_controller.js
